package robot.ascii;

import com.googlecode.lanterna.terminal.Terminal;

public interface Drawable
{	
	public abstract void draw(Terminal terminal);
}
