package robot.ascii;

import com.googlecode.lanterna.terminal.Terminal;

public class Arm implements Drawable
{
	@Override
	public void draw(Terminal terminal) 
	{
		int maxRow = terminal.getTerminalSize().getRows()-1;
		int maxCol = terminal.getTerminalSize().getColumns()-1;
		int height = 6;
		int width = 6;
		int depth = 2;
		
		//draws up/down bar
		for (int rowPos = maxRow; rowPos > maxRow - height; rowPos--)
		{
			terminal.moveCursor(maxCol - maxCol , rowPos);//arm 1 pos
			terminal.putCharacter('|');
			
			
		}
		//draws extend/contract bar
		for (int colPos = maxCol; colPos > maxCol - width; colPos--)
		{
			terminal.moveCursor(colPos - maxCol + width -1 , maxRow - height);//arm 2 pos
			terminal.putCharacter('-');
		}
		//draws raise/lower bar
		for (int rowPos = maxRow; rowPos > maxRow - depth; rowPos--)
		{
			terminal.moveCursor(maxCol - maxCol + width, rowPos - height + depth - 1);//arm 3 pos
			terminal.putCharacter('|');
		}
		
		/*public void up()
		{
			//move arm1 pos++ 
		}*/
		
		
		
		
		
		
		
		
		
		// TODO Auto-generated method stub
		
	}
}
