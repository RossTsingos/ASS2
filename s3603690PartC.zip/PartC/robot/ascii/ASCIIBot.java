package robot.ascii;

import robot.Robot;

import com.googlecode.lanterna.TerminalFacade;
import com.googlecode.lanterna.terminal.Terminal;

import control.RobotControl;

//Robot Assignment for Programming 1 s2 2016
//ASCIIBot classes written by Caspar Ryan
public class ASCIIBot implements Robot {
	// the Lanterna terminal
	private Terminal terminal;

	// array of blocks Block[]
	Block[] blocks = new Block[12];
	Bar[] bars = new Bar[12];

	// array of bars Bar[]
	// arm Arm arm = new Arm()

	// for simplicity I do not do graceful exiting code so just use the eclipse
	// STOP button to exit
	public static void main(String[] args) {
		// instantiate ASCIIBot and run control()
		new RobotControl().control(new ASCIIBot(), null, null);
	}

	// the constructor initialises the Lanterna Terminal
	public ASCIIBot() {
		// create the terminal 20 rows, 15 columns
		terminal = TerminalFacade.createSwingTerminal(22, 14);

		// required by Lanterna framework to initialise
		terminal.enterPrivateMode();
		terminal.setCursorVisible(false);

		terminal.clearScreen();
	}

	@Override
	public void init(int[] barHeights, int[] blockHeights, int height,
			int width, int depth) {

		// simple code example to help you get started!

		new Bar().draw(terminal);
		new Block().draw(terminal);
		new Arm().draw(terminal);

		// delay 100 milliseconds for next "frame"
		delayAnimation(100);

		// do real code here ..
		
		

		// for each bar in array crate a new bar
		// for each block in the array, create new block
		// crate a new arm based on height width depth

	}

	@Override
	public void pick() {
		// if arm3 is = total block height + 1
		//
		// elif Total block heght is < max bar height + blockHeight
		// raise until arm1 height is = max bar heght + block Height + 1
		//
		// TODO Auto-generated method stub

	}

	@Override
	public void drop() {
		// TODO Auto-generated method stub

	}

	@Override
	public void up() {
		// height ++
		// arm.up()
		// check if picked,,, if picked tell block block has moved
		// or make a block.up
		// redraw everything (drawComplete)
		// TODO Auto-generated method stub

	}

	@Override
	public void down() {
		// move height incrementally height--
		// TODO Auto-generated method stub

	}

	@Override
	public void contract() {
		// width--
		// TODO Auto-generated method stub

	}

	@Override
	public void extend() {
		// width++
		// TODO Auto-generated method stub

	}

	@Override
	public void lower() {
		// depth--
		// TODO Auto-generated method stub

	}

	@Override
	public void raise() {
		// depth++
		// TODO Auto-generated method stub

	}

	// delay in ms
	private void delayAnimation(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void drawComplete() {
		delayAnimation(100);
		terminal.clearScreen();
		for (Block block : blocks)
			block.draw(terminal);
		for (Bar bar : bars)
			bar.draw(terminal);
		// for each arm
	}
}
