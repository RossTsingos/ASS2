package robot.ascii;

import com.googlecode.lanterna.terminal.Terminal;
import control.RobotControl;

public class Bar implements Drawable {
	//call barHeights
	
	private RobotControl barHeights[];
	/*public void barDraw(RobotControl barHeights[])  {
		this.barHeights = barHeights;
		for (int i=0; barHeights[i] > i; i++ ){
			
		}
	}*/
	@Override
	public void draw(Terminal terminal) {
		// (0 index for terminal)
		 
		int maxRow = terminal.getTerminalSize().getRows() - 1;
		int maxCol = terminal.getTerminalSize().getColumns() - 1;
		
		int bar_height = 5;
		

		for (int rowPos = maxRow; rowPos > maxRow - bar_height; rowPos--) {
			
			terminal.moveCursor(maxCol / 2 - 1, rowPos);
			terminal.putCharacter('*');
		}

	}
}
