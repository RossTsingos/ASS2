package robot.ascii;

import com.googlecode.lanterna.terminal.Terminal;

public class Bar implements Drawable {
	//call barHeights
	

	@Override
	public void draw(Terminal terminal) {
		// (0 index for terminal)
		int maxRow = terminal.getTerminalSize().getRows() - 1;
		int maxCol = terminal.getTerminalSize().getColumns() - 1;

		int bar_height = 4;
		

		for (int rowPos = maxRow; rowPos > maxRow - bar_height; rowPos--) {
			
			terminal.moveCursor(maxCol / 2 - 1, rowPos);
			terminal.putCharacter('*');
		}

	}
}
