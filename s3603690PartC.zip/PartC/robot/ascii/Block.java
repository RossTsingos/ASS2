package robot.ascii;

import com.googlecode.lanterna.terminal.Terminal;

import control.RobotControl;

public class Block implements Drawable {
	// block height
	// block position (can move)(row and column)
	// Constructor
	private RobotControl blockHeights[];
	@Override
	public void draw(Terminal terminal) {
		int maxRow = terminal.getTerminalSize().getRows() - 1;
		int maxCol = terminal.getTerminalSize().getColumns() - 1;
		int block_height = 3;
		// if block height = 1>>>>

		for (int rowPos = maxRow; rowPos > maxRow - block_height; rowPos--) {
			terminal.moveCursor(maxCol / 2, rowPos);
			terminal.putCharacter('1');
		}
		// TODO Auto-generated method stub
	}
}
