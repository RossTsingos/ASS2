package control;

import robot.Robot;

// Robot Assignment for Programming 1 s2 2016
// Adapted by Caspar from original Robot code in RobotImpl.jar written by Dr Charles Thevathayan
public class RobotControl implements Control {
	private Robot robot;

	private static final int MAX_HEIGHT = 13;
	private static final int MAX_COL = 10;
	private static final int BAR_START_COL = 3;

	int[] barHeights;
	private int[] blockHeights;
	private int[] smallBlocksStackHeight = new int[] { 0, 0 };

	private int height = 2;
	private int width = 1;
	private int depth = 0;

	// called by RobotImpl
	// the unused arrays are based on cmd line params to RobotImpl not used in
	// this assignment
	@Override
	public void control(Robot robot, int barHeightsUnused[],
			int blockHeightsUnused[]) {
		// save robot so we can access it from other methods
		this.robot = robot;

		// ASSIGNMENT PART A
		// replace this code with a console based menu to populate the arrays
		int barHeights[] = new int[] { 1, 3, 7, 1, 1, 7 };
		int blockHeights[] = new int[] { 1, 3, 2, 3 };

		this.barHeights = barHeights;
		this.blockHeights = blockHeights;

		// initialise the robot
		robot.init(barHeights, blockHeights, height, width, depth);

		int destBarCol = BAR_START_COL;
		int barIndex = 0;
		for (int blockIndex = blockHeights.length - 1; blockIndex >= 0; blockIndex--) {
			// a simple private method to demonstrate how to control (assignment
			// PART B)
			moveToHeight(MAX_HEIGHT);

			moveArm2RightTo(MAX_COL);

			lowerArm3DownTo(MAX_HEIGHT - calculateStackHeight(blockIndex) - 1);
			// 37:47
			robot.pick();

			raiseArm3UpTo(0);

			if (blockHeights[blockIndex] == 3) {
				moveArm2LeftTo(destBarCol++);

				lowerArm3DownTo(MAX_HEIGHT - barHeights[barIndex++]
						- blockHeights[blockIndex] - 1);
			} else {

				moveArm2LeftTo(blockHeights[blockIndex]);
				int heightIndex = blockHeights[blockIndex] - 1;
				lowerArm3DownTo(MAX_HEIGHT
						- smallBlocksStackHeight[heightIndex] - blockHeights[blockIndex] - 1);
				smallBlocksStackHeight[heightIndex] += blockHeights[blockIndex];
			}
			robot.drop();

			raiseArm3UpTo(0);

		}
		// assignment part B implemented here

	}

	private void moveToHeight(int height) {
		while (this.height < height) {
			robot.up();
			this.height++;
		}
	}

	private void moveArm2RightTo(int col) {
		while (this.width < col) {
			robot.extend();
			this.width++;
		}
	}

	private void moveArm2LeftTo(int col) {
		while (this.width > col) {
			robot.contract();
			this.width--;
		}
	}

	private void lowerArm3DownTo(int depth) {
		while (this.depth < depth) {
			robot.lower();
			this.depth++;
		}
	}

	private void raiseArm3UpTo(int depth) {
		while (this.depth > depth) {
			robot.raise();
			this.depth--;
		}
	}

	private int calculateStackHeight(int blockIndex) {
		int total = 0;
		for (int i = 0; i <= blockIndex; i++)
			total += blockHeights[i];
		return total;
	}

	// assignment part B methods implemented here
}
